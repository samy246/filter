import React from "react";

function splice() {
  return <div></div>;
}

export default splice;
