import React from "react";

function NotFound() {
  return (
    <div>
      <p>Page not Found 404</p>
    </div>
  );
}

export default NotFound;
