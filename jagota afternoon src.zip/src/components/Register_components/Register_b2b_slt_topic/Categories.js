import meat from "../../../assets/images/catogeryimages/meat.jpeg";
import SeaFood from "../../../assets/images/catogeryimages/seefoods.jpeg";
import Pasta from "../../../assets/images/catogeryimages/pasta.jpeg";
import DairyProducts from "../../../assets/images/catogeryimages/diryProducts.jpeg";
import Backery from "../../../assets/images/catogeryimages/backery.jpeg";
import westrenGourmet from "../../../assets/images/catogeryimages/meat.jpeg";
import icecream from "../../../assets/images/catogeryimages/iceceem.jpeg";
import flour from "../../../assets/images/catogeryimages/flours.jpeg";
import snack from "../../../assets/images/catogeryimages/snacks.jpeg";
import wholeGrains from "../../../assets/images/catogeryimages/wholeGains.jpeg";
import beverage from "../../../assets/images/catogeryimages/beverage.jpeg";
import coocking from "../../../assets/images/catogeryimages/coocking.jpeg";
import chocolate from "../../../assets/images/catogeryimages/chocolate.jpeg";
import oil from "../../../assets/images/catogeryimages/oil.jpeg";
import wine from "../../../assets/images/catogeryimages/wine.jpeg";
import seasoning from "../../../assets/images/catogeryimages/seasoning.jpeg";
import salmon from "../../../assets/images/catogeryimages/salmon.jpeg";

const Items = [
  {
    id: 1,
    name: "Meat",
    img: meat,
  },
  {
    id: 2,
    name: "SeaFood",
    img: SeaFood,
  },
  {
    id: 3,
    name: "Pasta",
    img: Pasta,
  },
  {
    id: 4,
    name: "DairyProducts",
    img: DairyProducts,
  },
  {
    id: 5,
    name: "Backery",
    img: Backery,
  },
  {
    id: 6,
    name: "Westren Gourmet",
    img: westrenGourmet,
  },
  {
    id: 7,
    name: "IceCream",
    img: icecream,
  },
  {
    id: 8,
    name: "Flour",
    img: flour,
  },
  {
    id: 9,
    name: "Snack",
    img: snack,
  },

  {
    id: 10,
    name: "Whole Grains",
    img: wholeGrains,
  },
  {
    id: 11,
    name: "Salmon ",
    img: salmon,
  },
  {
    id: 12,
    name: "Beverage",
    img: beverage,
  },
  {
    id: 13,
    name: "Cooking Material",
    img: coocking,
  },
  {
    id: 14,
    name: "Chocolete",
    img: chocolate,
  },
  {
    id: 15,
    name: "Oil",
    img: oil,
  },
  {
    id: 16,
    name: "Wine",
    img: wine,
  },
  {
    id: 17,
    name: "Seasoning",
    img: seasoning,
  },
];
export default Items;
