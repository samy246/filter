const Supervisor_Level = [
  {
    id: "3",
    name: "Heleno Kaizer",
    phone: "+66 3 987 9343",
    email: "Heleno_K@gmail.com",
    username: "Heleno_K@gmail.com",
  },
  {
    id: "4",
    name: "Paladini Meuro",
    phone: "+66 3 987 9343",
    email: "Paladini _M@gmail.com",
    username: "Paladini _M@gmail.com",
  },
];

export default Supervisor_Level;
