export const Userlogs__Data = [
  {
    logstext: "Aiony Hurst added new Supervisor Is Justin Chen",
    date: "18/09/20 10:12:22",
    day: "Yesterday",
    activeclass: "active__shadow",
  },
  {
    logstext:
      "Heleno Kaizer added 5 Fresh Norwegian Pre-Rigor Salmon (1kg) to cart",
    date: "14/09/20 14:32:54",
    day: "5 days ago",
  },
  {
    logstext:
      "Aiony Hurst added 5 Tajima WagyuStriploin For Branch A (Central Grand Rama9)",
    date: "10/09/20 16:11:58",
    day: "1 week ago",
  },
  {
    logstext:
      "Aiony Hurst added 5 Fresh Norwegian Pre-Rigor Salmon (1kg) to cart",
    date: "10/09/20 15:45:12",
    day: "1 week ago",
  },
  {
    logstext:
      "Aiony Hurst added 5 Fresh Norwegian Pre-Rigor Salmon (1kg) to cart",
    date: "10/09/20 15:45:12",
    day: "1 week ago",
  },
];
