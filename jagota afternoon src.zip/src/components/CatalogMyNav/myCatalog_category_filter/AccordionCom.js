import React, { useEffect } from "react";
import './AccordionCom.scss'

function AccordionCom ({ data, handler, type, clear }) {
    return (
      <div className="accordion-item">
        <h6
          className="accordion-header accordion-button collapsed"
          id={`flush-heading${type}`}
          type="button"
          data-toggle="collapse"
          data-target={`#flush-collapse${type}`}
          aria-expanded="false"
          aria-controls={`flush-collapse${type}`}
        >
          <span>{type}</span>
          {/* <span className="AC__Clear" onClick={() => clear(type)}>Clear</span> */}
        </h6>
        <div
          id={`flush-collapse${type}`}
          className="accordion-collapse collapse"
          aria-labelledby={`flush-heading${type}`}
          data-bs-parent="#accordionFlushExample"
        >
          <div className="accordion-body">
            <div className="discount_tab">
              {data?.map((itm) => {
                return (
                  <div className="listing_type" key={itm?.short_code ? itm?.short_code : itm?.country_id ? itm?.country_id : itm?.id}>
                    <input
                      type="radio"
                      className="form-check-input"
                      name={type}
                      id={itm?.product_type_code ? itm?.product_type_code : itm?.short_code ? itm?.short_code : itm?.country_id ? itm?.country_id : itm?.id}
                      onClick={() => handler(itm?.product_type_code ? itm?.product_type_code : itm?.short_code ? itm?.short_code : itm?.country_id ? itm?.country_id : itm?.id)}
                    ></input>
                    <label htmlFor={itm?.product_type_code ? itm?.product_type_code : itm?.short_code ? itm?.short_code : itm?.country_id ? itm?.country_id : itm?.id}>
                      {itm?.label ? itm?.label : itm?.brand_name ? itm?.brand_name : itm.country_name ? itm?.country_name : itm.name}
                    </label>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    )
}

export default AccordionCom;