import Card_img1 from "../../../assets/images/home/ProductCard/productcard1.jpg";
import Card_img2 from "../../../assets/images/home/ProductCard/productcard2.jpg";
import Card_img3 from "../../../assets/images/home/ProductCard/productcard3.jpg";
import Card_img4 from "../../../assets/images/home/ProductCard/productcard4.jpg";
import Card_img5 from "../../../assets/images/home/ProductCard/productcard5.jpg";
import Card_img6 from "../../../assets/images/home/ProductCard/productcard6.jpg";

export const Catalog__Data = [
  {
    image: Card_img1,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img2,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img3,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img4,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img5,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img6,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img1,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img2,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img3,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img4,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img5,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img6,
    delvieryColor: "green",
    type: "SeaFoods",
    link: "/catalog/SeaFoods/details",
  },
  {
    image: Card_img1,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img2,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img3,
    delvieryColor: "green",
    type: "Meats",
    link: "/catalog/Meats/details",
  },
  {
    image: Card_img4,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
  {
    image: Card_img5,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
  {
    image: Card_img6,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
  {
    image: Card_img1,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
  {
    image: Card_img2,
    delvieryColor: "green",
    type: "Pasta",
    link: "/catalog/Pasta/details",
  },
  {
    image: Card_img3,
    delvieryColor: "green",
    type: "Pasta",
    link: "/catalog/Pasta/details",
  },
  {
    image: Card_img4,
    delvieryColor: "green",
    type: "Pasta",
    link: "/catalog/Pasta/details",
  },
  {
    image: Card_img5,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
  {
    image: Card_img6,
    delvieryColor: "green",
    type: "Dairy",
    link: "/catalog/Dairy/details",
  },
];
