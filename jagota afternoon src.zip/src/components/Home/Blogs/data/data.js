import slideImage_1 from "../../../../assets/images/Slider/slide_1.jpg"
import slideImage_2 from "../../../../assets/images/Slider/slide_2.jpg"
 const IMAGES = [
  {
    id: 1,
    src: slideImage_1,
    alt: "Placeholder image",
  },
  {
    id: 2,
    src: slideImage_2,
    alt: "Placeholder image",
  },
  {
    id: 3,
    src: slideImage_1,
    alt: "Placeholder image",
  },
  {
    id: 4,
    src: slideImage_2,
    alt: "Placeholder image",
  },
];
export default IMAGES

