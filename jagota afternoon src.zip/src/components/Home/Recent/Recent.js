import React from 'react'
import './Recent.scss'

function Recent() {
    return (
        <div className="recent">
            
        </div>
    )
}

export default Recent
